# Ellie's Three Cats

This mod replaces the three cats in the game with my three cats: Apollo, Godzilla, and Kevin. 

You can specify which cat replaces which cat option or set a cat replacement to "false" to disable the replacement.
